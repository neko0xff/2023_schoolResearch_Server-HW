
-- --------------------------------------------------------

--
-- 資料表結構 `Users`
--
-- 建立時間： 2023 年 08 月 15 日 03:51
--

DROP TABLE IF EXISTS `Users`;
CREATE TABLE `Users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `LoginName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的關聯 `Users`:
--

--
-- 資料表新增資料前，先清除舊資料 `Users`
--

TRUNCATE TABLE `Users`;
--
-- 傾印資料表的資料 `Users`
--

INSERT DELAYED IGNORE INTO `Users` (`id`, `username`, `password`, `LoginName`) VALUES
(20, 'user2', '$2b$10$rF82Uu.2bMpymmyJn7UEeua7ON2A/GSba1z4DsEq1sO3qHm5HgK4S', 'user2'),
(21, 'user1', '$2b$10$Ij3LmDQBcRocrR/FgsX5beaWeW6N4x8THW6u3SEVEFnkrC2Dh806e', 'user1'),
(22, 'user3', '$2b$10$2.rFvbr4MiOjIoPF8ktsx.Hcabs2PK1n90ui1ADnNIkUF3UxC/RQm', 'user3');
