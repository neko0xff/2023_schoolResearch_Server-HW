
-- --------------------------------------------------------

--
-- 資料表結構 `Switch01_Status`
--
-- 建立時間： 2023 年 08 月 15 日 03:51
--

DROP TABLE IF EXISTS `Switch01_Status`;
CREATE TABLE `Switch01_Status` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的關聯 `Switch01_Status`:
--

--
-- 資料表新增資料前，先清除舊資料 `Switch01_Status`
--

TRUNCATE TABLE `Switch01_Status`;
--
-- 傾印資料表的資料 `Switch01_Status`
--

INSERT DELAYED IGNORE INTO `Switch01_Status` (`id`, `name`, `status`) VALUES
(1, 'fan1', 0),
(2, 'fan2', 0);
