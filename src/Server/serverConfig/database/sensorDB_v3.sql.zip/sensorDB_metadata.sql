

--
-- 元資料
--
USE phpmyadmin;

--
-- 資料表 AQX_P_434 的元資料
--
-- 讀取資料表 phpmyadmin.pma__column_info 的資料時出現錯誤： #1100 - Table &#039;pma__column_info&#039; was not locked with LOCK TABLES
-- 讀取資料表 phpmyadmin.pma__table_uiprefs 的資料時出現錯誤： #1100 - Table &#039;pma__table_uiprefs&#039; was not locked with LOCK TABLES
-- 讀取資料表 phpmyadmin.pma__tracking 的資料時出現錯誤： #1100 - Table &#039;pma__tracking&#039; was not locked with LOCK TABLES

--
-- 資料表 Sensor01_Table 的元資料
--
-- 讀取資料表 phpmyadmin.pma__column_info 的資料時出現錯誤： #1100 - Table &#039;pma__column_info&#039; was not locked with LOCK TABLES
-- 讀取資料表 phpmyadmin.pma__table_uiprefs 的資料時出現錯誤： #1100 - Table &#039;pma__table_uiprefs&#039; was not locked with LOCK TABLES
-- 讀取資料表 phpmyadmin.pma__tracking 的資料時出現錯誤： #1100 - Table &#039;pma__tracking&#039; was not locked with LOCK TABLES

--
-- 資料表 Switch01_Status 的元資料
--
-- 讀取資料表 phpmyadmin.pma__column_info 的資料時出現錯誤： #1100 - Table &#039;pma__column_info&#039; was not locked with LOCK TABLES
-- 讀取資料表 phpmyadmin.pma__table_uiprefs 的資料時出現錯誤： #1100 - Table &#039;pma__table_uiprefs&#039; was not locked with LOCK TABLES
-- 讀取資料表 phpmyadmin.pma__tracking 的資料時出現錯誤： #1100 - Table &#039;pma__tracking&#039; was not locked with LOCK TABLES

--
-- 資料表 Switch01_StatusRec 的元資料
--
-- 讀取資料表 phpmyadmin.pma__column_info 的資料時出現錯誤： #1100 - Table &#039;pma__column_info&#039; was not locked with LOCK TABLES
-- 讀取資料表 phpmyadmin.pma__table_uiprefs 的資料時出現錯誤： #1100 - Table &#039;pma__table_uiprefs&#039; was not locked with LOCK TABLES
-- 讀取資料表 phpmyadmin.pma__tracking 的資料時出現錯誤： #1100 - Table &#039;pma__tracking&#039; was not locked with LOCK TABLES

--
-- 資料表 Users 的元資料
--
-- 讀取資料表 phpmyadmin.pma__column_info 的資料時出現錯誤： #1100 - Table &#039;pma__column_info&#039; was not locked with LOCK TABLES
-- 讀取資料表 phpmyadmin.pma__table_uiprefs 的資料時出現錯誤： #1100 - Table &#039;pma__table_uiprefs&#039; was not locked with LOCK TABLES
-- 讀取資料表 phpmyadmin.pma__tracking 的資料時出現錯誤： #1100 - Table &#039;pma__tracking&#039; was not locked with LOCK TABLES

--
-- 資料庫 sensorDB 的元資料
--
-- 讀取資料表 phpmyadmin.pma__bookmark 的資料時出現錯誤： #1100 - Table &#039;pma__bookmark&#039; was not locked with LOCK TABLES
-- 讀取資料表 phpmyadmin.pma__relation 的資料時出現錯誤： #1100 - Table &#039;pma__relation&#039; was not locked with LOCK TABLES
-- 讀取資料表 phpmyadmin.pma__savedsearches 的資料時出現錯誤： #1100 - Table &#039;pma__savedsearches&#039; was not locked with LOCK TABLES
-- 讀取資料表 phpmyadmin.pma__central_columns 的資料時出現錯誤： #1100 - Table &#039;pma__central_columns&#039; was not locked with LOCK TABLES
