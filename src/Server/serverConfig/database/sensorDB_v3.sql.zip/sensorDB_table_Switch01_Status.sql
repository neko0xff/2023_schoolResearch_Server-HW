
-- --------------------------------------------------------

--
-- 資料表結構 "Switch01_Status"
--
-- 建立時間： 2023 年 08 月 15 日 03:51
--

DROP TABLE IF EXISTS `Switch01_Status`;
CREATE TABLE "Switch01_Status" ;

--
-- 資料表的關聯 `Switch01_Status`:
--

--
-- 傾印資料表的資料 "Switch01_Status"
--

SET IDENTITY_INSERT "Switch01_Status" ON ;
INSERT INTO "Switch01_Status" ("id", "name", "status") VALUES
(1, 'fan1', 0),
(2, 'fan2', 0);

SET IDENTITY_INSERT "Switch01_Status" OFF;
