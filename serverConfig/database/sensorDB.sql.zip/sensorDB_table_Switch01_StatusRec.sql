
-- --------------------------------------------------------

--
-- 資料表結構 `Switch01_StatusRec`
--
-- 建立時間： 2023 年 04 月 23 日 03:36
--

DROP TABLE IF EXISTS `Switch01_StatusRec`;
CREATE TABLE `Switch01_StatusRec` (
  `id` int(11) NOT NULL,
  `switch` varchar(200) NOT NULL,
  `status` int(1) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的關聯 `Switch01_StatusRec`:
--

--
-- 傾印資料表的資料 `Switch01_StatusRec`
--

INSERT DELAYED IGNORE INTO `Switch01_StatusRec` (`id`, `switch`, `status`, `date`, `time`) VALUES
(1, 'fan1', 0, '2023-04-23', '11:37:06'),
(2, 'fan1', 1, '2023-04-23', '11:37:22'),
(3, 'fan1', 1, '2023-04-23', '11:44:05'),
(4, 'fan2', 1, '2023-04-23', '11:44:05'),
(5, 'fan2', 0, '2023-04-23', '11:44:05'),
(6, 'fan2', 0, '2023-04-23', '04:02:20'),
(7, 'fan1', 0, '2023-04-26', '14:29:37');
