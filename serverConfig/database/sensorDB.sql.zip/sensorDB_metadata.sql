
--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `Sensor01_Table`
--
ALTER TABLE `Sensor01_Table`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `Switch01_Status`
--
ALTER TABLE `Switch01_Status`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `Switch01_StatusRec`
--
ALTER TABLE `Switch01_StatusRec`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`id`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `Sensor01_Table`
--
ALTER TABLE `Sensor01_Table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=282;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `Switch01_Status`
--
ALTER TABLE `Switch01_Status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `Switch01_StatusRec`
--
ALTER TABLE `Switch01_StatusRec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `Users`
--
ALTER TABLE `Users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;


--
-- 元資料
--
USE `phpmyadmin`;

--
-- 資料表 Sensor01_Table 的元資料
--

--
-- 傾印資料表的資料 `pma__table_uiprefs`
--

INSERT DELAYED IGNORE INTO `pma__table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('master', 'sensorDB', 'Sensor01_Table', '[]', '2023-04-22 01:01:22');

--
-- 資料表 Switch01_Status 的元資料
--

--
-- 資料表 Switch01_StatusRec 的元資料
--

--
-- 資料表 Users 的元資料
--

--
-- 資料庫 sensorDB 的元資料
--
