-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- 主機： 192.168.1.111
-- 產生時間： 2024 年 01 月 18 日 05:46
-- 伺服器版本： 11.2.2-MariaDB
-- PHP 版本： 8.2.13

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `sensorDB`
--
CREATE DATABASE IF NOT EXISTS `sensorDB` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `sensorDB`;

-- --------------------------------------------------------

--
-- 資料表結構 `AQX_P_434`
--
-- 建立時間： 2024 年 01 月 18 日 05:42
-- 最後更新： 2024 年 01 月 18 日 05:45
--

DROP TABLE IF EXISTS `AQX_P_434`;
CREATE TABLE `AQX_P_434` (
  `siteid` int(100) NOT NULL,
  `sitename` varchar(100) NOT NULL,
  `aqi` int(100) NOT NULL,
  `monitordate` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的關聯 `AQX_P_434`:
--

--
-- 傾印資料表的資料 `AQX_P_434`
--

UPDATE `AQX_P_434` SET `siteid` = 1,`sitename` = '基隆',`aqi` = 41,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 1;
UPDATE `AQX_P_434` SET `siteid` = 2,`sitename` = '汐止',`aqi` = 48,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 2;
UPDATE `AQX_P_434` SET `siteid` = 3,`sitename` = '萬里',`aqi` = 39,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 3;
UPDATE `AQX_P_434` SET `siteid` = 4,`sitename` = '新店',`aqi` = 41,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 4;
UPDATE `AQX_P_434` SET `siteid` = 5,`sitename` = '土城',`aqi` = 43,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 5;
UPDATE `AQX_P_434` SET `siteid` = 6,`sitename` = '板橋',`aqi` = 52,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 6;
UPDATE `AQX_P_434` SET `siteid` = 7,`sitename` = '新莊',`aqi` = 56,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 7;
UPDATE `AQX_P_434` SET `siteid` = 8,`sitename` = '菜寮',`aqi` = 58,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 8;
UPDATE `AQX_P_434` SET `siteid` = 9,`sitename` = '林口',`aqi` = 35,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 9;
UPDATE `AQX_P_434` SET `siteid` = 10,`sitename` = '淡水',`aqi` = 40,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 10;
UPDATE `AQX_P_434` SET `siteid` = 11,`sitename` = '士林',`aqi` = 52,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 11;
UPDATE `AQX_P_434` SET `siteid` = 12,`sitename` = '中山',`aqi` = 57,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 12;
UPDATE `AQX_P_434` SET `siteid` = 13,`sitename` = '萬華',`aqi` = 61,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 13;
UPDATE `AQX_P_434` SET `siteid` = 14,`sitename` = '古亭',`aqi` = 35,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 14;
UPDATE `AQX_P_434` SET `siteid` = 15,`sitename` = '松山',`aqi` = 50,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 15;
UPDATE `AQX_P_434` SET `siteid` = 16,`sitename` = '大同',`aqi` = 62,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 16;
UPDATE `AQX_P_434` SET `siteid` = 17,`sitename` = '桃園',`aqi` = 43,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 17;
UPDATE `AQX_P_434` SET `siteid` = 18,`sitename` = '大園',`aqi` = 59,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 18;
UPDATE `AQX_P_434` SET `siteid` = 19,`sitename` = '觀音',`aqi` = 52,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 19;
UPDATE `AQX_P_434` SET `siteid` = 20,`sitename` = '平鎮',`aqi` = 58,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 20;
UPDATE `AQX_P_434` SET `siteid` = 21,`sitename` = '龍潭',`aqi` = 61,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 21;
UPDATE `AQX_P_434` SET `siteid` = 22,`sitename` = '湖口',`aqi` = 51,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 22;
UPDATE `AQX_P_434` SET `siteid` = 23,`sitename` = '竹東',`aqi` = 46,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 23;
UPDATE `AQX_P_434` SET `siteid` = 24,`sitename` = '新竹',`aqi` = 52,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 24;
UPDATE `AQX_P_434` SET `siteid` = 25,`sitename` = '頭份',`aqi` = 48,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 25;
UPDATE `AQX_P_434` SET `siteid` = 26,`sitename` = '苗栗',`aqi` = 44,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 26;
UPDATE `AQX_P_434` SET `siteid` = 27,`sitename` = '三義',`aqi` = 50,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 27;
UPDATE `AQX_P_434` SET `siteid` = 28,`sitename` = '豐原',`aqi` = 57,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 28;
UPDATE `AQX_P_434` SET `siteid` = 29,`sitename` = '沙鹿',`aqi` = 52,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 29;
UPDATE `AQX_P_434` SET `siteid` = 30,`sitename` = '大里',`aqi` = 65,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 30;
UPDATE `AQX_P_434` SET `siteid` = 31,`sitename` = '忠明',`aqi` = 60,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 31;
UPDATE `AQX_P_434` SET `siteid` = 32,`sitename` = '西屯',`aqi` = 64,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 32;
UPDATE `AQX_P_434` SET `siteid` = 33,`sitename` = '彰化',`aqi` = 51,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 33;
UPDATE `AQX_P_434` SET `siteid` = 34,`sitename` = '線西',`aqi` = 50,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 34;
UPDATE `AQX_P_434` SET `siteid` = 35,`sitename` = '二林',`aqi` = 66,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 35;
UPDATE `AQX_P_434` SET `siteid` = 36,`sitename` = '南投',`aqi` = 71,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 36;
UPDATE `AQX_P_434` SET `siteid` = 37,`sitename` = '斗六',`aqi` = 84,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 37;
UPDATE `AQX_P_434` SET `siteid` = 38,`sitename` = '崙背',`aqi` = 74,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 38;
UPDATE `AQX_P_434` SET `siteid` = 39,`sitename` = '新港',`aqi` = 71,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 39;
UPDATE `AQX_P_434` SET `siteid` = 40,`sitename` = '朴子',`aqi` = 64,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 40;
UPDATE `AQX_P_434` SET `siteid` = 41,`sitename` = '臺西',`aqi` = 38,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 41;
UPDATE `AQX_P_434` SET `siteid` = 42,`sitename` = '嘉義',`aqi` = 84,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 42;
UPDATE `AQX_P_434` SET `siteid` = 43,`sitename` = '新營',`aqi` = 74,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 43;
UPDATE `AQX_P_434` SET `siteid` = 44,`sitename` = '善化',`aqi` = 70,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 44;
UPDATE `AQX_P_434` SET `siteid` = 45,`sitename` = '安南',`aqi` = 87,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 45;
UPDATE `AQX_P_434` SET `siteid` = 46,`sitename` = '臺南',`aqi` = 87,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 46;
UPDATE `AQX_P_434` SET `siteid` = 47,`sitename` = '美濃',`aqi` = 112,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 47;
UPDATE `AQX_P_434` SET `siteid` = 48,`sitename` = '橋頭',`aqi` = 108,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 48;
UPDATE `AQX_P_434` SET `siteid` = 49,`sitename` = '仁武',`aqi` = 112,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 49;
UPDATE `AQX_P_434` SET `siteid` = 50,`sitename` = '鳳山',`aqi` = 73,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 50;
UPDATE `AQX_P_434` SET `siteid` = 51,`sitename` = '大寮',`aqi` = 86,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 51;
UPDATE `AQX_P_434` SET `siteid` = 52,`sitename` = '林園',`aqi` = 132,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 52;
UPDATE `AQX_P_434` SET `siteid` = 53,`sitename` = '楠梓',`aqi` = 108,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 53;
UPDATE `AQX_P_434` SET `siteid` = 54,`sitename` = '左營',`aqi` = 122,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 54;
UPDATE `AQX_P_434` SET `siteid` = 56,`sitename` = '前金',`aqi` = 118,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 56;
UPDATE `AQX_P_434` SET `siteid` = 57,`sitename` = '前鎮',`aqi` = 73,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 57;
UPDATE `AQX_P_434` SET `siteid` = 58,`sitename` = '小港',`aqi` = 100,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 58;
UPDATE `AQX_P_434` SET `siteid` = 59,`sitename` = '屏東',`aqi` = 136,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 59;
UPDATE `AQX_P_434` SET `siteid` = 60,`sitename` = '潮州',`aqi` = 129,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 60;
UPDATE `AQX_P_434` SET `siteid` = 61,`sitename` = '恆春',`aqi` = 44,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 61;
UPDATE `AQX_P_434` SET `siteid` = 62,`sitename` = '臺東',`aqi` = 35,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 62;
UPDATE `AQX_P_434` SET `siteid` = 63,`sitename` = '花蓮',`aqi` = 36,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 63;
UPDATE `AQX_P_434` SET `siteid` = 64,`sitename` = '陽明',`aqi` = 41,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 64;
UPDATE `AQX_P_434` SET `siteid` = 65,`sitename` = '宜蘭',`aqi` = 37,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 65;
UPDATE `AQX_P_434` SET `siteid` = 66,`sitename` = '冬山',`aqi` = 35,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 66;
UPDATE `AQX_P_434` SET `siteid` = 67,`sitename` = '三重',`aqi` = 67,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 67;
UPDATE `AQX_P_434` SET `siteid` = 68,`sitename` = '中壢',`aqi` = 62,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 68;
UPDATE `AQX_P_434` SET `siteid` = 69,`sitename` = '竹山',`aqi` = 93,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 69;
UPDATE `AQX_P_434` SET `siteid` = 70,`sitename` = '永和',`aqi` = 42,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 70;
UPDATE `AQX_P_434` SET `siteid` = 71,`sitename` = '復興',`aqi` = 79,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 71;
UPDATE `AQX_P_434` SET `siteid` = 72,`sitename` = '埔里',`aqi` = 118,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 72;
UPDATE `AQX_P_434` SET `siteid` = 75,`sitename` = '馬祖',`aqi` = 41,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 75;
UPDATE `AQX_P_434` SET `siteid` = 77,`sitename` = '金門',`aqi` = 53,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 77;
UPDATE `AQX_P_434` SET `siteid` = 78,`sitename` = '馬公',`aqi` = 50,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 78;
UPDATE `AQX_P_434` SET `siteid` = 80,`sitename` = '關山',`aqi` = 35,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 80;
UPDATE `AQX_P_434` SET `siteid` = 83,`sitename` = '麥寮',`aqi` = 59,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 83;
UPDATE `AQX_P_434` SET `siteid` = 84,`sitename` = '富貴角',`aqi` = 45,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 84;
UPDATE `AQX_P_434` SET `siteid` = 85,`sitename` = '大城',`aqi` = 58,`monitordate` = '2024-01-17' WHERE `AQX_P_434`.`siteid` = 85;

-- --------------------------------------------------------

--
-- 資料表結構 `CFP_P_02`
--
-- 建立時間： 2024 年 01 月 18 日 05:42
--

DROP TABLE IF EXISTS `CFP_P_02`;
CREATE TABLE `CFP_P_02` (
  `id` int(11) NOT NULL,
  `name` text DEFAULT NULL,
  `coe` float DEFAULT NULL,
  `unit` text DEFAULT NULL,
  `departmentname` text DEFAULT NULL,
  `announcementyear` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的關聯 `CFP_P_02`:
--

-- --------------------------------------------------------

--
-- 資料表結構 `customVar_StatusRec`
--
-- 建立時間： 2024 年 01 月 18 日 05:42
--

DROP TABLE IF EXISTS `customVar_StatusRec`;
CREATE TABLE `customVar_StatusRec` (
  `id` int(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `ValueName` varchar(255) NOT NULL,
  `num` int(255) DEFAULT 0,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的關聯 `customVar_StatusRec`:
--

-- --------------------------------------------------------

--
-- 資料表結構 `Devices`
--
-- 建立時間： 2024 年 01 月 18 日 05:42
--

DROP TABLE IF EXISTS `Devices`;
CREATE TABLE `Devices` (
  `id` int(11) NOT NULL,
  `device` varchar(255) NOT NULL,
  `serialnumber` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的關聯 `Devices`:
--

-- --------------------------------------------------------

--
-- 資料表結構 `Sensor01_Table`
--
-- 建立時間： 2024 年 01 月 18 日 05:42
--

DROP TABLE IF EXISTS `Sensor01_Table`;
CREATE TABLE `Sensor01_Table` (
  `id` int(11) NOT NULL,
  `hum` double NOT NULL,
  `temp` double NOT NULL,
  `tvoc` double NOT NULL,
  `co` double NOT NULL,
  `co2` double NOT NULL,
  `pm25` double NOT NULL,
  `o3` double NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的關聯 `Sensor01_Table`:
--

-- --------------------------------------------------------

--
-- 資料表結構 `Switch01_Status`
--
-- 建立時間： 2024 年 01 月 18 日 05:42
--

DROP TABLE IF EXISTS `Switch01_Status`;
CREATE TABLE `Switch01_Status` (
  `id` int(11) NOT NULL,
  `name` varchar(200) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的關聯 `Switch01_Status`:
--

-- --------------------------------------------------------

--
-- 資料表結構 `Switch01_StatusRec`
--
-- 建立時間： 2024 年 01 月 18 日 05:42
--

DROP TABLE IF EXISTS `Switch01_StatusRec`;
CREATE TABLE `Switch01_StatusRec` (
  `id` int(11) NOT NULL,
  `switch` varchar(200) NOT NULL,
  `status` int(1) NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的關聯 `Switch01_StatusRec`:
--

-- --------------------------------------------------------

--
-- 資料表結構 `Users`
--
-- 建立時間： 2024 年 01 月 18 日 05:42
--

DROP TABLE IF EXISTS `Users`;
CREATE TABLE `Users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `LoginName` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `customvar01` int(255) DEFAULT 0,
  `customvar02` int(255) DEFAULT 0,
  `customvar03` int(255) DEFAULT 0,
  `customvar04` int(255) DEFAULT 0,
  `customvar05` int(255) DEFAULT 0,
  `customvar06` int(255) DEFAULT 0,
  `customvar07` int(255) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- 資料表的關聯 `Users`:
--

--
-- 已傾印資料表的索引
--

--
-- 資料表索引 `AQX_P_434`
--
ALTER TABLE `AQX_P_434`
  ADD PRIMARY KEY (`siteid`);

--
-- 資料表索引 `CFP_P_02`
--
ALTER TABLE `CFP_P_02`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `customVar_StatusRec`
--
ALTER TABLE `customVar_StatusRec`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `Devices`
--
ALTER TABLE `Devices`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `Sensor01_Table`
--
ALTER TABLE `Sensor01_Table`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `Switch01_Status`
--
ALTER TABLE `Switch01_Status`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `Switch01_StatusRec`
--
ALTER TABLE `Switch01_StatusRec`
  ADD PRIMARY KEY (`id`);

--
-- 資料表索引 `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`id`);

--
-- 在傾印的資料表使用自動遞增(AUTO_INCREMENT)
--

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `AQX_P_434`
--
ALTER TABLE `AQX_P_434`
  MODIFY `siteid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `CFP_P_02`
--
ALTER TABLE `CFP_P_02`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1112;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `customVar_StatusRec`
--
ALTER TABLE `customVar_StatusRec`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `Devices`
--
ALTER TABLE `Devices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `Sensor01_Table`
--
ALTER TABLE `Sensor01_Table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=374;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `Switch01_Status`
--
ALTER TABLE `Switch01_Status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `Switch01_StatusRec`
--
ALTER TABLE `Switch01_StatusRec`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- 使用資料表自動遞增(AUTO_INCREMENT) `Users`
--
ALTER TABLE `Users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;


--
-- 元資料
--
USE `phpmyadmin`;

--
-- 資料表 AQX_P_434 的元資料
--

--
-- 資料表 CFP_P_02 的元資料
--

--
-- 資料表 customVar_StatusRec 的元資料
--

--
-- 資料表 Devices 的元資料
--

--
-- 資料表 Sensor01_Table 的元資料
--

--
-- 資料表 Switch01_Status 的元資料
--

--
-- 資料表 Switch01_StatusRec 的元資料
--

--
-- 資料表 Users 的元資料
--

--
-- 傾印資料表的資料 `pma__table_uiprefs`
--

UPDATE `pma__table_uiprefs` SET `username` = 'master',`db_name` = 'sensorDB',`table_name` = 'Users',`prefs` = '{\"sorted_col\":\"`Users`.`username` ASC\"}',`last_update` = '2024-01-07 01:16:06' WHERE `pma__table_uiprefs`.`username` = 'master' AND `pma__table_uiprefs`.`db_name` = 'sensorDB' AND `pma__table_uiprefs`.`table_name` = 'Users';

--
-- 資料庫 sensorDB 的元資料
--
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
